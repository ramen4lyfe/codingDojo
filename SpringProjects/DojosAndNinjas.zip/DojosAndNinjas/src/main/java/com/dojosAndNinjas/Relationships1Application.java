package com.dojosAndNinjas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Relationships1Application {

	public static void main(String[] args) {
		SpringApplication.run(Relationships1Application.class, args);
	}

}
