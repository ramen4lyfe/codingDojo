package com.saveTravels3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaveTravels3Application {

	public static void main(String[] args) {
		SpringApplication.run(SaveTravels3Application.class, args);
	}

}
