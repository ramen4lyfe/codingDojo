package com.saveTravels3.Repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.saveTravels3.Models.expenseModel;

public interface expenseRepository extends CrudRepository<expenseModel, Long> {
	List<expenseModel> findAll();
}
