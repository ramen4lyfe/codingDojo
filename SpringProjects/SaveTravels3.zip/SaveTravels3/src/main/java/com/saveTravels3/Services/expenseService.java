package com.saveTravels3.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.saveTravels3.Models.expenseModel;
import com.saveTravels3.Repositories.expenseRepository;


    
@Service
public class expenseService {
	@Autowired
	private expenseRepository expenseRepo;
	
	public expenseService(expenseRepository expeseRepo, expenseRepository expenseRepo) {
		this.expenseRepo = expenseRepo;
	}
	
	public List<expenseModel> all() {
		return this.expenseRepo.findAll();
	}
	
	// creates an expend
	public expenseModel createExpense(expenseModel expense) {
		return this.expenseRepo.save(expense);
	}
	
	// updates an expense
	public expenseModel updateExpense(expenseModel expense) {
		return this.expenseRepo.save(expense);
	}
	
	//retrieve an expense
	public expenseModel find(Long id) {
		Optional<expenseModel> optional = expenseRepo.findById(id);
		if(optional.isPresent()){
			return optional.get();
		}
		else {
			return null;
		}
	}
	
	public void delete(Long id) {
		expenseRepo.deleteById(id);
	}
}


