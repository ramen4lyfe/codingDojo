package com.omikuji2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Omikuji2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
