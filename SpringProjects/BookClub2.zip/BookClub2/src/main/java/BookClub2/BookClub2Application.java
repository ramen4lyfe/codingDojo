package BookClub2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookClub2Application {

	public static void main(String[] args) {
		SpringApplication.run(BookClub2Application.class, args);
	}

}
