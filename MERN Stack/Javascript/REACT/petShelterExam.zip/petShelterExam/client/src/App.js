import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import PetList from "./components/PetList";
import CreatePet from "./components/CreatePet";
import UpdatePet from "./components/UpdatePet";
import NavTab from "./components/Nav";
import PetDetails from "./components/PetDetails";
import Card from 'react-bootstrap/Card';

function App() {
  return (
    <div className="Container-fluid">
      <div className="row">
        <div className="p-4">
          <h1>Pet Shelter</h1>
          <BrowserRouter>
            <Card>
              <Card.Header>
                <NavTab />
              </Card.Header>
              <Card.Body>
                <Routes>
                  <Route path="/api/pet/list" element={<PetList />} />
                  <Route path="/api/pet/new" element={<CreatePet />} />
                  <Route path="/api/pet/update/:id" element={<UpdatePet />} />
                  <Route path="/api/pet/details/:id" element={<PetDetails />} />
                </Routes>
              </Card.Body>
            </Card>
          </BrowserRouter>
        </div>
      </div>
    </div>
  );
};

export default App;
