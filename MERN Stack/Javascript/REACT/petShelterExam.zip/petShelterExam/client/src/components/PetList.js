import React from 'react';
import { useState,useEffect } from 'react';
import axios from "axios";
import { Link } from 'react-router-dom'; 


const PetList = () => {
    const [petData, setPetData] = useState([]);
    useEffect(() => {
        axios.get("http://localhost:8000/api/pet")
          .then((response) => {
              console.log(response.data);
              setPetData(response.data);
          })
          .catch((err) => {
              console.log(err);
          });
  }, []);

  const handleDelete = (idFromBelow) => {
    axios
    .delete(`http://localhost:8000/api/pet/${idFromBelow}`)
    .then((response) => {
        console.log("Adoption Success");
        console.log(response);
        //filtered out recently adopted pet
        const adoptedPet = petData.filter((pet) => {
            return pet._id !== idFromBelow;
        });
        setPetData(adoptedPet);
    })
    .catch((err) => {
        console.log("Error deleting", err.response);
    });
};

  return (
    <div className="container">
        <div className="row">
            <div className="mt-2">
                <h3>Adopt These Pets Today!</h3>
                <table className="table table-hover mt-3 align-middle">
                    <thead>
                        <tr>
                            <th scope="col">Pet's Name</th>
                            <th scope="col">Pet's Type</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>

                    <tbody className="table-group-divider">
                        {petData.map((pet,index) => {
                            return(
                                <tr key={pet._id}>
                                    <td>{pet.name}</td>
                                    <td>{pet.type}</td>
                                    <td>
                                        <Link to={`/api/pet/details/${pet._id}`} className="btn btn-info btn-sm m-2">Details</Link>
                                        <Link to={`/api/pet/update/${pet._id}`} className="btn btn-warning btn-sm m-2">Edit</Link>
                                        {/* <button onClick={() => handleDelete(pet._id)} className="btn btn-success btn-sm m-2">Adopt This Pet!</button> */}
                                    </td>
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
  )
};

export default PetList;