import Nav from 'react-bootstrap/Nav';
import { NavLink } from 'react-router-dom';


function NavTab() {
    return (
            <Nav justify variant="tabs">
                <Nav.Item>
                    <Nav.Link as={NavLink} to={"/api/pet/list"}>Pet list</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                    <Nav.Link as={NavLink} to={"/api/pet/new"}>Add a pet!</Nav.Link>
                </Nav.Item>
            </Nav>
    );
}

export default NavTab;