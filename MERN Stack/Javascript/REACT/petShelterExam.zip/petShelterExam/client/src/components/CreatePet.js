import React from 'react'
import axios from 'axios';
import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

const CreatePet = () => {
    const [name,setName] = useState("");
    const [type,setType] = useState("");
    const [description,setDescription] = useState("");
    const [skill1,setSkill1] = useState("");
    const [skill2,setSkill2] = useState("");
    const [skill3,setSkill3] = useState("");

    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post("http://localhost:8000/api/pet", {name, type, description, skill1, skill2, skill3})
        .then(response => {
            console.log(response);
            navigate("/api/pet/list");
        })
        .catch((err) => {
            // console.log(err.response.data.err.errors);
            console.log(err)
            setErrors(err.response.data.error.errors);
        });
    };

  return (
    <div className="container ">
        <div className="row">
            <div className="mt-2">
                <h3>Know a pet needing a home?</h3>
                <form onSubmit={handleSubmit} className="row">
                    <div className="form-group col-6 mb-4 mt-2">
                        <label className="mb-2" htmlFor="name">What is your pet's name? </label>
                        <input 
                            type="text"
                            className="form-control mb-4"
                            onChange={(e) => setName(e.target.value)}
                            value={name}
                        />
                        {errors.name ? <p className="text-danger">{errors.name.message}</p> : null}
                        
                        <label className="mb-2" htmlFor="name">What is the type of your pet?</label>
                        <input 
                            type="text"
                            className="form-control mb-4"
                            onChange={(e) => setType(e.target.value)}
                            value={type}
                        />
                        {errors.type ? <p className="text-danger">{errors.type.message}</p> : null}

                        <label className="mb-2" htmlFor="position">Can you tell us more info about your pet?</label>
                        <input 
                            type="textarea"
                            className="form-control mb-4"
                            onChange={(e) => setDescription(e.target.value)}
                            value={description}
                        />
                        {errors.description ? <p className="text-danger">{errors.description.message}</p> : null}
                    </div>
                    <div className="form-group col-6 mb-4 mt-2">
                        <label className="mb-2" htmlFor="skill1">Skill 1: </label>
                            <input 
                                type="text"
                                className="form-control mb-4"
                                onChange={(e) => setSkill1(e.target.value)}
                                value={skill1}
                            />

                        <label className="mb-2" htmlFor="skill2">Skill 2: </label>
                            <input 
                                type="text"
                                className="form-control mb-4"
                                onChange={(e) => setSkill2(e.target.value)}
                                value={skill2}
                            />

                        <label className="mb-2" htmlFor="skill3">Skill 3: </label>
                            <input 
                                type="text"
                                className="form-control mb-4"
                                onChange={(e) => setSkill3(e.target.value)}
                                value={skill3}
                            />
                    </div>
                    <button type="submit" className="btn btn-primary btn-sm mb-2">Add Pet</button>
                    <Link to="/api/pet/list" className="btn btn-secondary btn-sm">Cancel</Link>
                </form>
            </div>
        </div>
    </div>
  );
};

export default CreatePet;