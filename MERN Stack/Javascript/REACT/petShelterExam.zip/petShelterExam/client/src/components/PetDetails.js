import React,{useState, useEffect} from 'react';
import {Link, useParams, useNavigate} from 'react-router-dom';
import axios from 'axios';

const PetDetails = (props) => {
    const {id} = useParams();
    const [pet, setPet] = useState({});
    const navigate = useNavigate(); 

    useEffect(() => {
        axios.get(`http://localhost:8000/api/pet/${id}`)
          .then((res) => {
              console.log(res);
              console.log(res.data);
              setPet(res.data);
          })
          .catch((err)=>console.log(err));
      }, [id])

      const handleDelete = (idFromBelow) => {
        axios
        .delete(`http://localhost:8000/api/pet/${idFromBelow}`)
        .then((response) => {
            console.log("Adoption Success");
            console.log(response);
            navigate("/api/pet/list");
        })
        .catch((err) => {
            console.log("Error deleting", err.response);
        });
    };

  return (
    <div className="container">
        <div className="row">
            <div className="p-2">
                <h4>Details about: {pet.name}</h4>
                <table className="table-sm align-top">
                        <tr>
                            <th>Pet type: </th>
                            <td>{pet.type}</td>
                        </tr>
                        <tr>
                            <th>Description: </th>
                            <tr>{pet.description}</tr>
                        </tr>
                        <tr>
                            <th>Skills: </th>
                            <tr>{pet.skill1}</tr>
                            <tr>{pet.skill2}</tr>
                            <tr>{pet.skill3}</tr>
                        </tr>
                </table>
                <Link to={`/api/pet/update/${pet._id}`} className="btn btn-warning btn-sm m-2">Update Info</Link>
                <button onClick={() => handleDelete(pet._id)} className="btn btn-success btn-sm">Adopt {pet.name}!</button>
            </div>
        </div>
    </div>
  )
}

export default PetDetails;