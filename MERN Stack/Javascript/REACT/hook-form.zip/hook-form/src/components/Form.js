import React, { useState } from 'react';

const Form = (props) => {
    // write getters and setter for form fields
    const [firstName, setFirstName ] = useState(" ");
    const [lastName, setLastName ] = useState(" ");
    const [email, setEmail ] = useState(" ");
    const [password, setPassword ] = useState(" ");
    
    // e variable is for event
    const createForm = (e) =>{
        // prevent browser's default refresh. So we should always have this in our code
        e.preventDefault();

        // now we are building the object using ES6 shorthand
        const newUser = {firstName, lastName, email, password};
        console.log ("Welcome", newUser);
        setFirstName("");
        setLastName("");
        setEmail("");
        setPassword("");
    };

    return (
        <div>
            <form onSubmit={createForm}>
                <div>
                    <label> First Name: </label>
                    <input type="text" value={firstName} onChange={ (e) => setFirstName(e.target.value)}/>
                </div>
                <div>
                    <label> Last Name: </label>
                    <input type="text" value={lastName} onChange={ (e) => setLastName(e.target.value)}/>
                </div>
                <div>
                    <label> Email: </label>
                    <input type="text" value={email} onChange={ (e) => setEmail(e.target.value)}/>
                </div>
                <div>
                    <label> Password: </label>
                    <input type="text" value={password} onChange={ (e) => setPassword(e.target.value)}/>
                </div>
            </form>

            <div>
                <h2>Your Form Live Data</h2>
                <p><label>First Name: </label> {firstName}</p>
                <p><label>Last Name: </label> {lastName}</p>
                <p><label>Email: </label> {email}</p>
                <p><label>Password: </label> {password}</p>
            </div>
        </div>
        
    );
}

export default Form;