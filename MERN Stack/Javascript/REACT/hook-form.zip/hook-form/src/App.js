import Form from './components/Form'
import './App.css';

function App() {
  return (
    <div className="App">
      <h2>This is a form</h2>
      <Form />
      </div>
    
  );
}

export default App;
