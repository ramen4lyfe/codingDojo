const authorsController = require("../controllers/authors.controller");


module.exports = (app)=> {
    app.post("/api/author", authorsController.createNewAuthor);
    app.get("/api/author", authorsController.getAllAuthors);
    app.get("/api/author/:id", authorsController.getOneAuthor);
    app.get("/api/author/:id", authorsController.getOneAuthor);
    app.put("/api/author/:id", authorsController.updateAuthor);
    app.delete("/api/author/:id", authorsController.deleteAuthor);
};