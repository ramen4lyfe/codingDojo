import axios from 'axios';
import React from 'react';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';


const NewAuthor = () => {
    const [name, setName] = useState("");
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();
    const handleSubmit =(e) => {
        e.preventDefault();
        axios.post("http://localhost:8000/api/author", {name})
        .then(response => {
            console.log(response);
            navigate("/");
        })
        .catch((err) => {
            console.log(err.response.data.err.errors);
            setErrors(err.response.data.err.errors);
        });
    };
  return (
    <div className="container">
        <div className="row justify-content-center">
            <div className="col-6">
            <Link to="/">Home</Link>
                <form onSubmit={handleSubmit}>
                    <div className="form-group mb-2">
                        <label htmlFor="name">Name</label>
                        <input 
                            type="text" 
                            className="form-control" 
                            onChange={(e) => setName(e.target.value)}
                            value={name}
                        />
                        {errors.name ? <p className="text-danger">{errors.name.message}</p> : null}
                    </div>
                    <button type="submit" className="btn btn-primary btn-sm">Submit</button>
                    <Link to="/" className="btn btn-secondary btn-sm">Cancel</Link>
                </form>
            </div>
        </div>
    </div>
  );
};

export default NewAuthor;