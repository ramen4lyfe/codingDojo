import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const DisplayAll = () => {
    const [allAuthors, setAllAuthors] = useState([])
    useEffect(() => {
      axios.get("http://localhost:8000/api/author")
        .then((response) => {
            console.log(response.data);
            setAllAuthors(response.data);
        })
        .catch((err) => {
            console.log(err.response);
        });
    }, []);

const handleDelete = (idFromBelow) => {
    axios
    .delete(`http://localhost:8000/api/author/${idFromBelow}`)
    .then((response) => {
        console.log("Delete Success");
        console.log(response);
        //filtered out recently deleted author
        const deletedAuthor = allAuthors.filter((author) => {
            return author._id !== idFromBelow;
        });
        setAllAuthors(deletedAuthor);
    })
    .catch((err) => {
        console.log("Error deleting", err.response);
    });
};
    
  return (
    <div className="container p-2">
        <div className="row justify-content-center">
            <div className="col-6">
                <div className="row mb-2"><Link to="/new" className="btn btn-primary btn-sm btn-block">Add an author</Link></div>
                <h5>We have quotes by:</h5>
            <table className="table">
                <thead className="thead-dark">
                    <tr>
                        <th scope="col">Author</th>
                        <th scope="col">Action Available</th>
                    </tr>
                </thead>
                <tbody>
                    {allAuthors.map((author, index) => {
                    return(
                        <tr key={author._id}>
                            <td>{author.name}</td>
                            <td>
                                <Link to={`/edit/${author._id}`} className="btn btn-warning btn-sm m-2">Edit</Link>
                                {/* <Link to={`/delete/${author._id}`} className="btn btn-danger btn-sm m-2">Delete</Link> */}
                                <button onClick={() => handleDelete(author._id)} className="btn btn-danger btn-sm">Delete</button>
                            </td>
                        </tr>
                    );
                    })}
                </tbody>
            </table>
            </div>
        </div>
    </div>
  )
}

export default DisplayAll;