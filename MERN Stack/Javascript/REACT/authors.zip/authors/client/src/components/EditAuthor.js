import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom';


const EditAuthor = () => {
    const { id } = useParams();
    
    const [authorName, setAuthorName] = useState("");
    useEffect(()=>{
        axios
        .get(`http://localhost:8000/api/author/${id}`)
        .then((response) => {
            console.log(response.data);
            setAuthorName(response.data.name);
        })
        .catch((err) => console.log(err.response));
        
    },[]);

    const navigate = useNavigate();
    
    const [errors, setErrors] = useState({});
    
    const handleSubmit = (e) => {
        e.preventDefault();
        axios
        .put(`http://localhost:8000/api/author/${id}`, {name: authorName})
        .then((response) => {
            console.log(response);
            navigate("/");
        })
        .catch((err) => {
            console.log(err.response.data.err.errors);
            setErrors(err.response.data.err.errors);
        });
    };

  return (
    <div className="container">
        <div className="row justify-content-center">
            <div className="col-6">
                <Link to="/">Home</Link>
                <form onSubmit={handleSubmit}>
                    <div className="form-group mb-2">
                        <label htmlFor="name">Name</label>
                        <input 
                            className="form-control" 
                            type="text"
                            id="name"
                            value={authorName}
                            onChange={(e) => setAuthorName(e.target.value)}
                        />
                        {errors.name ? <p className="text-danger">{errors.name.message}</p> : null}
                    </div>
                    <button type="submit" className="btn btn-primary btn-sm m-2">Submit</button>
                    <Link to="/" className="btn btn-secondary btn-sm">Cancel</Link>
                </form>
            </div>
        </div>
    </div>
  );
};

export default EditAuthor;