import './App.css';
import React from 'react';
import CreateProduct from './component/CreateProduct';

function App() {
  return (
    <div className="App">
      <CreateProduct />
      
    </div>
  );
}

export default App;
