export default function Prcing () {
    return <h1>Pricing</h1>
}
